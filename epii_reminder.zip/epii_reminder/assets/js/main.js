$(document).ready(function(){
    $('.slider-active').slick({
        infinite: true,
        slidesToShow: 1,
        autoplay:true,
        arrows:false,
        autoplaySpeed:1000,
        slidesToScroll: 1
      });
})