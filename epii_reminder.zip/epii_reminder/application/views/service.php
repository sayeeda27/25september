<div class="service-area pt-70 pb-70">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-3">
                <div class="service-wrapper text-center">
                    <i class="fas fa-syringe"></i>
                    <h3>Increase immune</h3>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                    Vel mollitia ipsum quis cumque quos sunt voluptates non, quaerat accusamus ipsam 
                   </p>
                    <a href="#" class="btn">view services</a>
                </div>
            </div>
            <div class="col-xl-3">
                <div class="service-wrapper text-center">
                    <i class="fas fa-syringe"></i>
                    <h3>Increase immune</h3>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                    Vel mollitia ipsum quis cumque quos sunt voluptates non, quaerat accusamus ipsam 
                   </p>
                    <a href="#" class="btn">view services</a>
                </div>
            </div>
            <div class="col-xl-3">
                <div class="service-wrapper text-center">
                    <i class="fas fa-syringe"></i>
                    <h3>Increase immune</h3>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                    Vel mollitia ipsum quis cumque quos sunt voluptates non, quaerat accusamus ipsam 
                   </p>
                    <a href="#" class="btn">view services</a>
                </div>
            </div>
            <div class="col-xl-3">
                <div class="service-wrapper text-center">
                    <i class="fas fa-syringe"></i>
                    <h3>Increase immune</h3>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                    Vel mollitia ipsum quis cumque quos sunt voluptates non, quaerat accusamus ipsam 
                   </p>
                    <a href="#" class="btn">view services</a>
                </div>
            </div>
        </div>
    </div>
</div>