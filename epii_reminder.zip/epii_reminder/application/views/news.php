<div class="news-area pt-30 pb-30 feature-area">
   <div class="container">
        <div class="row">
           <div class="col-xl-12">
             <div class="area-title text-center">
               <h3>News</h3>
               <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</p>
             </div>
           </div>
        </div>
        <div class="row">
           <div class="col-xl-4">
              <div class="latest-news">
                 <div class="news-thumb">
                    <a href="#"><img src="<?php echo base_url();?>assets/img/Rectangle 1.jpg" alt=""></a>
                 </div>
                 <div class="news-content">
                   <h3><a href="#">how to increase child immune system</a></h3>
                   <div class="news-meta">
                     <span>07 May</span>
                     <span class="meta-line"></span>
                   </div>
                   <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                    Vel mollitia ipsum quis cumque quos sunt voluptates non</p>
                   <a href="#" class="btn">Continue Reading</a>
                 </div>
              </div>
           </div>
           <div class="col-xl-4">
              <div class="latest-news">
                 <div class="news-thumb">
                    <a href="#"><img src="<?php echo base_url();?>assets/img/Rectangle 1.jpg" alt=""></a>
                 </div>
                 <div class="news-content">
                   <h3><a href="#">how to increase child immune system</a></h3>
                   <div class="news-meta">
                     <span>07 May</span>
                     <span class="meta-line"></span>
                   </div>
                   <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                    Vel mollitia ipsum quis cumque quos sunt voluptates non</p>
                   <a href="#" class="btn">Continue Reading</a>
                 </div>
              </div>
           </div>
           <div class="col-xl-4">
              <div class="latest-news">
                 <div class="news-thumb">
                    <a href="#"><img src="<?php echo base_url();?>assets/img/Rectangle 1.jpg" alt=""></a>
                 </div>
                 <div class="news-content">
                   <h3><a href="#">how to increase child immune system</a></h3>
                   <div class="news-meta">
                     <span>07 May</span>
                     <span class="meta-line"></span>
                   </div>
                   <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                    Vel mollitia ipsum quis cumque quos sunt voluptates non</p>
                   <a href="#" class="btn">Continue Reading</a>
                 </div>
              </div>
           </div>
        </div>
   </div>
</div>